# KISS Vocational Centre: training, production and distribution

A student design prototype for a software design problem statement. Trainees register in one program, log production shifts, and earn a certificate. Production feeds a store, the store dispatches to schools, and a forecast shows how much to make next month. It is not an official KISS website, and all names and figures are sample data.

It is a static site: plain HTML, CSS and JavaScript, no build step, no dependencies, no third-party requests. Fonts are self-hosted.

## Deploy to Vercel

All files sit at one level. `index.html` must be at the top of the repo (or of the folder you deploy). There is no build step.

**Via GitHub:** upload every file in this folder to the root of a repo (Add file > Upload files, select all files, drag them in, commit), then import the repo at https://vercel.com/new. Framework Preset: Other. Leave build and install commands empty. Click Deploy.

**Via CLI:** run `npx vercel --prod` inside this folder.

If the site shows a Vercel "404 NOT_FOUND" page, the files are inside a subfolder of the repo. Either move them to the repo root, or set Settings > Build and Deployment > Root Directory to that subfolder and redeploy.

## Run it locally

    python3 -m http.server 8080

Then open http://localhost:8080.

## Things to know

- **Saved in the browser.** Changes are kept in `localStorage` on the visitor's own device only. Nothing is sent anywhere. "Reset sample data" at the bottom clears it.
- **Not indexed.** `index.html` has `<meta name="robots" content="noindex">` because the site uses the KISS name and is unofficial. Delete that line to allow search engines to list it.
- **Fonts.** Rozha One, Mukta and Noto Sans Oriya, all under the SIL Open Font License (`LICENSES.txt`).
- **Odia labels.** The four stage names (ପ୍ରଶିକ୍ଷଣ, ଉତ୍ପାଦନ, ଭଣ୍ଡାର, ବିତରଣ) should be checked by an Odia speaker before you present this.

## Changing the sample data

Everything the prototype starts with sits at the top of `app.js`: `PROGRAMS`, `ITEMS`, `SCHOOLS` and the seed `trainees`. Colours and type are tokens at the top of `styles.css`. After changing the seed data, use "Reset sample data" so your browser stops loading the older saved copy.

## Rules the prototype uses

- A student can join only one program.
- Production score = hours worked + units made.
- Certificate target: 400, or 240 for fundamentals of computers (training only, no product).
- Stock leaves the store only by dispatch, and a dispatch cannot exceed what is in the store.
- Forecast = average monthly use over three months x (staff now / staff when that use was measured). Make = demand + buffer - in store.
